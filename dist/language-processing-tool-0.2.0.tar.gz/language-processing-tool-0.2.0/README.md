# Language Processing Tool

This Python package provides functionality to process PDFs and detect languages in the documents.

## Installation

You can install the package using pip:


## Usage

For batch processing:

process-pdfs /path/to/input/ /path/to/csv_file.csv /path/to/output/



For single PDF processing:

process-pdfs path.pdf
