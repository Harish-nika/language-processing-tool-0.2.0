import language_processing_tool
print(language_processing_tool.__version__)

#in CMD 

#Batch Processing (multiple PDFs):
#python sourcecode.py /FE_Documents/ISIN/ /home/harish/intern/language_clustering/filenames_csv.csv /home/harish 4

#Single PDF Processing:
#python sourcecode.py /FE_Documents/ISIN/ES1316617-ES1028292-ES1430422.pdf
